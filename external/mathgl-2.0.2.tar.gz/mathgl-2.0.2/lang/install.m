pkg install mathgl.tar.gz
